JYOTISH SEVA — PROFESSIONAL DASHBOARD PHASE 1 (LOCAL DEMO)
==========================================================

START
-----
1. Extract the ZIP file.
2. Open index.html in a modern browser. For map tiles, geocoding, PWA and browser permissions, use localhost or HTTPS rather than file://.
3. Owner demo login:
   Username / phone: 9999999999
   Password: DemoOwner#2026
4. In Owner Login, configure at least one future availability date and one or more slots before testing a booking.
5. Create a customer account, log in, then create a booking using a date/slot published by the owner.

PHASE 1 FEATURES
----------------
- Birth date is restricted to 31 December of the previous calendar year.
- Birth time uses 12-hour AM/PM format.
- Birthplace can be searched on an OpenStreetMap map or selected by clicking the map; coordinates are stored with the booking. Customers can also enter coordinates manually.
- Device geolocation is optional and clearly warns that current device location may not be the historical birth location.
- Owner can publish appointment dates and slots. Customers see only published slots. A selected slot is removed from availability after booking in this local demo.
- Customer level-2 dashboard displays profile, bookings, payment status and report records belonging to the logged-in phone account.
- Owner dashboard includes a Kundali/Patrika to Excel workspace. Owner uploads a source reference, manually verifies the 12 house positions, and exports a workbook containing Planet Positions, House Diagram and Source & Notes sheets.
- Excel export uses SheetJS loaded from a public CDN.
- Existing web/PWA/Capacitor starter files are retained.

IMPORTANT LIMITATIONS — NOT PRODUCTION READY
--------------------------------------------
This is a local browser prototype. Data uses localStorage and is not shared across devices or users. It is not secure authentication or a production database. Do not enter real customer personal data or real birth details.

MAP:
Map display/search uses OpenStreetMap services. Search and map tiles need internet access. The selected coordinates must be checked by the customer against the actual place of birth. Device geolocation returns the device's current location, not the historical birth location.

PAYMENTS:
Razorpay is shown as an integration option only; no live payment is processed. Production Razorpay needs a Razorpay merchant account, Key ID in the client, and Key Secret stored only on a secure backend. The backend must create orders and verify payment signatures/webhooks. Do not put the Key Secret in index.html. Manual UPI proof uploads in this demo are browser-local only.

KUNDALI / PATRIKA TO EXCEL:
This phase provides a structured owner-assisted conversion workflow and a sample 12-house diagram sheet. It does NOT automatically parse every PDF, scanned image, handwriting, DOCX, regional chart style or arbitrary diagram. The owner must verify and enter house/planet positions before export. Preserving a source chart's exact geometry requires a dedicated document/OCR/layout-recognition pipeline and human verification; this needs a separate development phase and sample source files from the owner.

PRODUCTION ARCHITECTURE REQUIRED BEFORE PUBLIC LAUNCH
-----------------------------------------------------
- Hosted backend/database with server-side owner/customer roles and access control.
- Secure password hashing and account recovery. No-OTP login can be supported, but password reset must use an authenticated recovery process or owner-assisted identity checks; a phone number alone is not proof of ownership.
- Private object storage for payment proofs and reports, signed download links, size/type validation, audit trail and backups.
- Razorpay order creation and payment verification on backend, webhook verification, refund/reconciliation flow.
- Server-side appointment slot locking/transaction to prevent two customers booking the same slot concurrently.
- Privacy policy, terms, data retention/deletion process, HTTPS, production logging and security testing.
- Android signed AAB and iOS archive/build plus respective store accounts and compliance checks.

No Supabase project was created and KA-KA QARCIS is not modified.


LATEST UPDATE: Birth time dropdowns, Google Maps preview, owner payment settings for UPI/QR and Razorpay selection, and supplied Patrika-to-Excel conversion workbook included. Local demo only; no real payments/backend.
