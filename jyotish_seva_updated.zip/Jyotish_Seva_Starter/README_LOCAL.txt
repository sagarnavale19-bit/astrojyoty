RUN LOCALLY
1. Double-click index.html for a quick trial (map, birth time, owner login, converters work with internet).
2. For Google/Facebook login and Razorpay, serve over localhost:
   python3 -m http.server 8080   (inside this folder), then open http://localhost:8080
3. Google: create an OAuth Web Client in Google Cloud Console, add http://localhost:8080 as Authorized JavaScript origin, paste the Client ID in Owner > Payment settings.
4. Facebook: create an app, enable Facebook Login, paste the App ID. Facebook needs HTTPS for live use.
5. Razorpay: paste a TEST Key ID (rzp_test_...). Never paste the Key Secret. Live payments need a backend to create orders and verify signatures.
Owner login is hidden: click the brand name 5 times quickly, or press Alt+Shift+O. Demo login: 9999999999 / DemoOwner#2026 (change it inside the owner page).
